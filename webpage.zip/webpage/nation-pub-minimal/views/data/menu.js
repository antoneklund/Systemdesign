var burgers = [
    {"name": "Originalburgare",
     "kcal": 1337,
     "lactose": true,
     "gluten": false,
     "src": "pics/Burgers-Max-Original.jpg";
    },
    {"name": "Cheese'n'Bacon",
     "kcal": 2000,
     "lactose": true,
     "gluten": true,
     "src": "pics/Burgers-GDL-Cheese-n-bacon.jpg";
    },
    {"name": "Halluomiburgare",
     "kcal": 400,
     "lactose": false,
     "gluten": false,
     "src": "pics/Burgers-GDL-BBQ-Halloumi-2017.jpg";
    }
]
